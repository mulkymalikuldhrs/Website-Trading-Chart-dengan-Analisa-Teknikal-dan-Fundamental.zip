# Arsitektur Website Trading Chart

## Arsitektur Aplikasi

### Frontend (React)
- **Framework:** React dengan TypeScript
- **Styling:** Tailwind CSS
- **Charting:** Lightweight Charts
- **State Management:** React Context API atau Zustand
- **HTTP Client:** Axios untuk API calls

### Backend (Opsional)
- **Framework:** Flask (jika diperlukan untuk logika kompleks)
- **Database:** SQLite untuk menyimpan konfigurasi atau data cache

### API Integration
- **Market Data:** Finnhub API
- **Economic Calendar:** Finnhub API
- **Crypto Data:** Binance API (untuk data kripto yang lebih lengkap)

## Struktur Komponen React

```
src/
├── components/
│   ├── Chart/
│   │   ├── TradingChart.tsx          # Komponen utama chart
│   │   ├── ChartControls.tsx         # Kontrol timeframe, pair selection
│   │   ├── Indicators/
│   │   │   ├── OrderBlock.tsx        # Order Block indicator
│   │   │   ├── FairValueGap.tsx      # Fair Value Gap indicator
│   │   │   ├── BreakerBlock.tsx      # Breaker Block indicator
│   │   │   ├── LiquidityZones.tsx    # Liquidity zones
│   │   │   └── MarketStructure.tsx   # BOS/CHoCH indicators
│   │   └── SessionHighlights.tsx     # Killzone & session highlights
│   ├── Analysis/
│   │   ├── TechnicalAnalysis.tsx     # Panel analisa teknikal
│   │   ├── FundamentalAnalysis.tsx   # Panel analisa fundamental
│   │   └── SentimentAnalysis.tsx     # Panel analisa sentimen
│   ├── Signals/
│   │   ├── SignalPanel.tsx           # Panel sinyal trading
│   │   ├── SignalCard.tsx            # Kartu individual sinyal
│   │   └── SignalHistory.tsx         # Riwayat sinyal
│   ├── News/
│   │   ├── EconomicCalendar.tsx      # Kalender ekonomi
│   │   └── NewsImpact.tsx            # Dampak berita pada pair
│   ├── Layout/
│   │   ├── Header.tsx                # Header dengan navigation
│   │   ├── Sidebar.tsx               # Sidebar dengan pair list
│   │   └── Footer.tsx                # Footer
│   └── Common/
│       ├── Loading.tsx               # Loading components
│       ├── ErrorBoundary.tsx         # Error handling
│       └── Modal.tsx                 # Modal components
├── hooks/
│   ├── useMarketData.tsx             # Hook untuk data pasar
│   ├── useSignals.tsx                # Hook untuk sinyal trading
│   └── useEconomicCalendar.tsx       # Hook untuk kalender ekonomi
├── services/
│   ├── finnhubApi.ts                 # Service untuk Finnhub API
│   ├── binanceApi.ts                 # Service untuk Binance API
│   └── signalGenerator.ts            # Service untuk generate sinyal
├── utils/
│   ├── tradingLogic.ts               # Logika trading (BOS, CHoCH, dll)
│   ├── indicators.ts                 # Kalkulasi indikator
│   └── constants.ts                  # Konstanta dan konfigurasi
├── types/
│   ├── market.ts                     # Type definitions untuk data pasar
│   ├── signals.ts                    # Type definitions untuk sinyal
│   └── indicators.ts                 # Type definitions untuk indikator
└── App.tsx                           # Main App component
```

## Layout dan UI/UX Design

### Layout Utama
```
┌─────────────────────────────────────────────────────────────┐
│                        Header                                │
│  [Logo] [Pair Selector] [Timeframe] [Session Status]        │
├─────────────────────────────────────────────────────────────┤
│ Side │                                                      │
│ bar  │                 Trading Chart                        │
│      │              (Lightweight Charts)                    │
│ Pair │                                                      │
│ List │                                                      │
│      │                                                      │
├─────────────────────────────────────────────────────────────┤
│                    Bottom Panel (Tabs)                      │
│ [Signals] [Technical Analysis] [Fundamental] [Calendar]     │
│                                                             │
│  Signal Cards / Analysis Content / Economic Events          │
└─────────────────────────────────────────────────────────────┘
```

### Komponen UI Utama

1. **Header:**
   - Logo dan nama aplikasi
   - Dropdown pair selector (Major, Cross, Exotic, Crypto)
   - Timeframe selector (M1, M5, M15, M30, H1, H4, D1, W1, MN)
   - Session status indicator (Asia/London/NY)
   - Killzone indicator

2. **Sidebar:**
   - Daftar pasangan mata uang yang dapat dipilih
   - Kategori: Major Pairs, Cross Pairs, Exotic Pairs, Crypto
   - Search functionality

3. **Trading Chart:**
   - Chart utama menggunakan Lightweight Charts
   - Overlay indikator (OB, FVG, BB, Liquidity Zones)
   - Session highlights (background colors untuk killzone)
   - Market structure markers (BOS, CHoCH)

4. **Bottom Panel (Tabbed):**
   - **Tab Signals:** Kartu sinyal dengan entry, SL, TP
   - **Tab Technical Analysis:** Analisa teknikal otomatis
   - **Tab Fundamental:** Analisa fundamental dan sentimen
   - **Tab Calendar:** Kalender ekonomi dengan impact rating

### Color Scheme dan Design System

**Colors:**
- Primary: Blue (#3B82F6)
- Secondary: Green (#10B981) untuk bullish
- Accent: Red (#EF4444) untuk bearish
- Background: Dark theme (#1F2937, #111827)
- Text: Light gray (#F9FAFB, #D1D5DB)

**Typography:**
- Heading: Inter Bold
- Body: Inter Regular
- Monospace: JetBrains Mono (untuk prices)

**Components:**
- Rounded corners (border-radius: 8px)
- Subtle shadows
- Smooth transitions (300ms)
- Hover effects

## Wireframe Konsep

### Desktop Layout
```
┌─────────────────────────────────────────────────────────────┐
│ [🏠 TradingSignal] [EUR/USD ▼] [H1 ▼] [🔴 London Killzone]  │
├─────────────────────────────────────────────────────────────┤
│ Major  │                                                    │
│ ✓EURUSD│         📈 CHART AREA 📈                          │
│  GBPUSD│    (Candlestick + Indicators)                      │
│  USDJPY│                                                    │
│ Cross  │                                                    │
│  EURGBP│                                                    │
│  EURJPY│                                                    │
│ Crypto │                                                    │
│  BTCUSD│                                                    │
│  ETHUSD│                                                    │
├─────────────────────────────────────────────────────────────┤
│ [📊 Signals] [🔧 Technical] [📰 Fundamental] [📅 Calendar]  │
│                                                             │
│ 🟢 EUR/USD BUY Signal                                       │
│ Entry: 1.0850 | SL: 1.0830 | TP: 1.0890 | RR: 1:2         │
│                                                             │
│ 🔴 GBP/USD SELL Signal                                      │
│ Entry: 1.2650 | SL: 1.2670 | TP: 1.2610 | RR: 1:2         │
└─────────────────────────────────────────────────────────────┘
```

### Mobile Layout (Responsive)
```
┌─────────────────┐
│ [☰] TradingSignal│
│ [EUR/USD ▼] [H1▼]│
├─────────────────┤
│                 │
│   📈 CHART 📈   │
│                 │
│                 │
├─────────────────┤
│ [Signals][Tech] │
│                 │
│ 🟢 EUR/USD BUY  │
│ 1.0850→1.0890   │
│                 │
│ 🔴 GBP/USD SELL │
│ 1.2650→1.2610   │
└─────────────────┘
```


