import React, { useState, useEffect } from 'react';

const ALPHA_VANTAGE_API_KEY = 'I8HZZ5CRDBQG6IPT';
const ALPHA_VANTAGE_BASE_URL = 'https://www.alphavantage.co/query';

// Comprehensive trading pairs
const TRADING_PAIRS = {
  'Major Pairs': [
    'EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'USD/CAD', 'NZD/USD'
  ],
  'Minor Pairs': [
    'EUR/GBP', 'EUR/JPY', 'EUR/CHF', 'EUR/AUD', 'EUR/CAD', 'EUR/NZD',
    'GBP/JPY', 'GBP/CHF', 'GBP/AUD', 'GBP/CAD', 'GBP/NZD',
    'AUD/JPY', 'AUD/CHF', 'AUD/CAD', 'AUD/NZD',
    'CAD/JPY', 'CAD/CHF', 'CHF/JPY', 'NZD/JPY', 'NZD/CHF', 'NZD/CAD'
  ],
  'Exotic Pairs': [
    'USD/SGD', 'USD/HKD', 'USD/THB', 'USD/ZAR', 'USD/MXN', 'USD/TRY',
    'EUR/SEK', 'EUR/NOK', 'EUR/PLN', 'EUR/CZK', 'EUR/HUF', 'EUR/TRY',
    'GBP/SEK', 'GBP/NOK', 'GBP/PLN', 'GBP/ZAR', 'GBP/TRY'
  ],
  'Commodities': [
    'XAU/USD', 'XAG/USD', 'USOIL', 'UKOIL'
  ],
  'Cryptocurrency': [
    'BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD', 'ADA/USD', 'DOT/USD',
    'LINK/USD', 'BCH/USD', 'XLM/USD', 'EOS/USD', 'TRX/USD', 'BNB/USD'
  ]
};

// Social media links
const SOCIAL_MEDIA = [
  { name: 'Instagram', icon: '📷', url: 'https://instagram.com/mulkymalikuldhr', color: 'bg-pink-600' },
  { name: 'Twitter', icon: '🐦', url: 'https://twitter.com/mulkymalikuldhr', color: 'bg-blue-500' },
  { name: 'LinkedIn', icon: '💼', url: 'https://linkedin.com/in/mulkymalikuldhr', color: 'bg-blue-700' },
  { name: 'YouTube', icon: '📺', url: 'https://youtube.com/@mulkymalikuldhr', color: 'bg-red-600' },
  { name: 'TikTok', icon: '🎵', url: 'https://tiktok.com/@mulkymalikuldhr', color: 'bg-black' },
  { name: 'Telegram', icon: '✈️', url: 'https://t.me/mulkymalikuldhr', color: 'bg-blue-400' }
];

// E-wallet donation with deep links
const DONATION_WALLETS = [
  { name: 'DANA', logo: '💳', color: 'bg-blue-600', link: 'https://link.dana.id/qr/2u4d9fvh' },
  { name: 'OVO', logo: '🟣', color: 'bg-purple-600', link: 'https://ovo.id/app/payment' },
  { name: 'GoPay', logo: '🟢', color: 'bg-green-600', link: 'https://gojek.com/gopay/transfer' },
  { name: 'SeaBank', logo: '🔵', color: 'bg-blue-800', link: 'https://seabank.id/transfer' },
  { name: 'ShopeePay', logo: '🧡', color: 'bg-orange-600', link: 'https://shopee.co.id/pay' },
  { name: 'LinkAja', logo: '🔴', color: 'bg-red-600', link: 'https://linkaja.id/transfer' }
];

// Market Sessions Configuration
const MARKET_SESSIONS = {
  ASIA: {
    name: 'Asia Session',
    start: { hour: 0, minute: 0 }, // 00:00 GMT
    end: { hour: 9, minute: 0 },   // 09:00 GMT
    timezone: 'GMT+0',
    color: 'bg-yellow-600',
    icon: '🌅'
  },
  LONDON: {
    name: 'London Session',
    start: { hour: 8, minute: 0 }, // 08:00 GMT
    end: { hour: 17, minute: 0 },  // 17:00 GMT
    timezone: 'GMT+0',
    color: 'bg-blue-600',
    icon: '🏛️'
  },
  NEWYORK: {
    name: 'New York Session',
    start: { hour: 13, minute: 0 }, // 13:00 GMT
    end: { hour: 22, minute: 0 },   // 22:00 GMT
    timezone: 'GMT+0',
    color: 'bg-green-600',
    icon: '🗽'
  }
};

// Market Session Component
const MarketSessionStatus = ({ isDarkMode }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [sessionStatus, setSessionStatus] = useState({});

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);
      
      // Calculate session status
      const utcHour = now.getUTCHours();
      const utcMinute = now.getUTCMinutes();
      const currentMinutes = utcHour * 60 + utcMinute;
      
      const sessions = {};
      
      Object.entries(MARKET_SESSIONS).forEach(([key, session]) => {
        const startMinutes = session.start.hour * 60 + session.start.minute;
        const endMinutes = session.end.hour * 60 + session.end.minute;
        
        let isOpen = false;
        let timeToNext = 0;
        
        if (startMinutes <= endMinutes) {
          // Same day session
          isOpen = currentMinutes >= startMinutes && currentMinutes < endMinutes;
          if (isOpen) {
            timeToNext = endMinutes - currentMinutes;
          } else if (currentMinutes < startMinutes) {
            timeToNext = startMinutes - currentMinutes;
          } else {
            timeToNext = (24 * 60) - currentMinutes + startMinutes;
          }
        } else {
          // Overnight session
          isOpen = currentMinutes >= startMinutes || currentMinutes < endMinutes;
          if (isOpen && currentMinutes >= startMinutes) {
            timeToNext = (24 * 60) - currentMinutes + endMinutes;
          } else if (isOpen && currentMinutes < endMinutes) {
            timeToNext = endMinutes - currentMinutes;
          } else {
            timeToNext = startMinutes - currentMinutes;
          }
        }
        
        const hours = Math.floor(timeToNext / 60);
        const minutes = timeToNext % 60;
        
        sessions[key] = {
          ...session,
          isOpen,
          timeToNext: `${hours}h ${minutes}m`,
          status: isOpen ? 'OPEN' : 'CLOSED'
        };
      });
      
      setSessionStatus(sessions);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-4 border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
          🌍 Market Sessions
        </h3>
        <div className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
          UTC: {currentTime.toUTCString().slice(17, 25)}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {Object.entries(sessionStatus).map(([key, session]) => (
          <div key={key} className={`${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'} rounded-lg p-3 border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-lg">{session.icon}</span>
                <span className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  {session.name}
                </span>
              </div>
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                session.isOpen 
                  ? 'bg-green-600 text-white' 
                  : 'bg-red-600 text-white'
              }`}>
                {session.status}
              </span>
            </div>
            
            <div className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
              {String(session.start.hour).padStart(2, '0')}:{String(session.start.minute).padStart(2, '0')} - {String(session.end.hour).padStart(2, '0')}:{String(session.end.minute).padStart(2, '0')} GMT
            </div>
            
            <div className={`text-xs ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              {session.isOpen ? 'Closes in:' : 'Opens in:'} <span className="font-mono">{session.timeToNext}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// TradingView Widget Component
const TradingViewWidget = ({ symbol, isDarkMode }) => {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: symbol.replace('/', ''),
      interval: "15",
      timezone: "Etc/UTC",
      theme: isDarkMode ? "dark" : "light",
      style: "1",
      locale: "en",
      enable_publishing: false,
      backgroundColor: isDarkMode ? "rgba(17, 24, 39, 1)" : "rgba(255, 255, 255, 1)",
      gridColor: isDarkMode ? "rgba(55, 65, 81, 0.3)" : "rgba(200, 200, 200, 0.3)",
      hide_top_toolbar: true, // Hide top toolbar
      hide_legend: true, // Hide legend
      save_image: false,
      container_id: "tradingview_chart",
      studies: [], // Explicitly removed studies to hide built-in indicators
      toolbar_bg: isDarkMode ? "#111827" : "#ffffff", // Match background color
      withdateranges: false, // Hide date ranges
      hide_side_toolbar: true, // Hide side toolbar
      allow_symbol_change: false, // Prevent symbol change from widget
      details: false, // Hide details panel
      hotlist: false, // Hide hotlist
      calendar: false, // Hide calendar
      news: false, // Hide news
      watchlist: false, // Hide watchlist
      show_popup_button: false, // Hide TradingView popup button
      popup_width: "1000",
      popup_height: "650"
    });

    const container = document.getElementById('tradingview_chart');
    if (container) {
      container.innerHTML = '';
      container.appendChild(script);
    }

    return () => {
      if (container) {
        container.innerHTML = '';
      }
    };
  }, [symbol, isDarkMode]);

  return (
    <div 
      id="tradingview_chart" 
      className={`w-full h-full ${isDarkMode ? 'bg-gray-900' : 'bg-white'} rounded-lg border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}
      style={{ minHeight: '600px' }} // Increased height for better visibility
    />
  );
};

// Visitor Notes Component
const VisitorNotes = ({ isDarkMode }) => {
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState('');
  const [visitorName, setVisitorName] = useState('');

  useEffect(() => {
    // Load notes from localStorage
    const savedNotes = localStorage.getItem('tradingSignalNotes');
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
  }, []);

  const addNote = () => {
    if (newNote.trim() && visitorName.trim()) {
      const note = {
        id: Date.now(),
        name: visitorName,
        message: newNote,
        timestamp: new Date().toLocaleString()
      };
      
      const updatedNotes = [note, ...notes].slice(0, 10); // Keep only last 10 notes
      setNotes(updatedNotes);
      localStorage.setItem('tradingSignalNotes', JSON.stringify(updatedNotes));
      
      setNewNote('');
      setVisitorName('');
    }
  };

  return (
    <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-4 border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
      <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        💬 Visitor Notes
      </h3>
      
      <div className="mb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-2">
          <input
            type="text"
            placeholder="Your name"
            value={visitorName}
            onChange={(e) => setVisitorName(e.target.value)}
            className={`px-3 py-2 rounded border text-sm ${
              isDarkMode 
                ? 'bg-gray-900 border-gray-700 text-white placeholder-gray-400' 
                : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
            }`}
          />
          <button
            onClick={addNote}
            disabled={!newNote.trim() || !visitorName.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Add Note
          </button>
        </div>
        <textarea
          placeholder="Leave a note about the trading signals or website..."
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          className={`w-full px-3 py-2 rounded border text-sm ${
            isDarkMode 
              ? 'bg-gray-900 border-gray-700 text-white placeholder-gray-400' 
              : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
          }`}
          rows="3"
        />
      </div>
      
      <div className="space-y-3 max-h-60 overflow-y-auto">
        {notes.length === 0 ? (
          <div className={`text-center py-4 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            No notes yet. Be the first to leave a comment!
          </div>
        ) : (
          notes.map(note => (
            <div key={note.id} className={`${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'} rounded-lg p-3 border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
              <div className="flex justify-between items-start mb-2">
                <span className={`font-medium text-sm ${isDarkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                  {note.name}
                </span>
                <span className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  {note.timestamp}
                </span>
              </div>
              <p className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                {note.message}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// Notification Manager Component
const NotificationManager = () => {
  const [notificationPermission, setNotificationPermission] = useState('default');

  useEffect(() => {
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
      
      if (Notification.permission === 'default') {
        setTimeout(() => {
          requestNotificationPermission();
        }, 3000);
      }
    }
  }, []);

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      
      if (permission === 'granted') {
        new Notification('Trading Signal Pro', {
          body: '🎯 Real-time notifications enabled! You will receive trading signals.',
          icon: '/favicon.ico',
          badge: '/favicon.ico'
        });
      }
    }
  };

  return null;
};

function App() {
  const [currentPair, setCurrentPair] = useState('EUR/USD');
  const [currentTab, setCurrentTab] = useState('signals');
  const [signals, setSignals] = useState([]);
  const [technicalAnalysis, setTechnicalAnalysis] = useState({});
  const [fundamentalAnalysis, setFundamentalAnalysis] = useState({});
  const [economicCalendar, setEconomicCalendar] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPrice, setCurrentPrice] = useState('Loading...');
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Auto dark/light mode based on time
  useEffect(() => {
    const hour = new Date().getHours();
    setIsDarkMode(hour < 6 || hour >= 18); // Dark mode from 6 PM to 6 AM
  }, []);

  // Advanced POI Analysis
  const analyzePOI = (priceData, timeframe) => {
    const poi = {
      orderBlocks: [],
      fairValueGaps: [],
      breakerBlocks: [],
      liquidityZones: [],
      fibonacciLevels: []
    };

    const price = parseFloat(priceData);
    
    // Order Blocks with detailed analysis
    poi.orderBlocks = [
      {
        type: 'Bullish OB',
        timeframe: 'H1',
        level: (price - 0.0015).toFixed(5),
        strength: 'High',
        validity: '24h',
        confluence: ['FVG', 'Liquidity', 'Structure'],
        entryZone: `${(price - 0.0020).toFixed(5)} - ${(price - 0.0010).toFixed(5)}`,
        invalidation: (price - 0.0025).toFixed(5)
      },
      {
        type: 'Bearish OB',
        timeframe: 'M30',
        level: (price + 0.0020).toFixed(5),
        strength: 'Medium',
        validity: '12h',
        confluence: ['Structure', 'Session High'],
        entryZone: `${(price + 0.0015).toFixed(5)} - ${(price + 0.0025).toFixed(5)}`,
        invalidation: (price + 0.0030).toFixed(5)
      }
    ];

    // Fair Value Gaps with enhanced details
    poi.fairValueGaps = [
      {
        type: 'Bullish FVG',
        timeframe: 'M15',
        high: (price + 0.0008).toFixed(5),
        low: (price + 0.0003).toFixed(5),
        filled: false,
        strength: 'High',
        confluence: ['OB', 'Liquidity'],
        description: 'Potential bounce zone'
      },
      {
        type: 'Bearish FVG',
        timeframe: 'M5',
        high: (price - 0.0003).toFixed(5),
        low: (price - 0.0008).toFixed(5),
        filled: false,
        strength: 'Medium',
        confluence: ['Resistance', 'Session Low'],
        description: 'Potential rejection zone'
      }
    ];

    // Breaker Blocks
    poi.breakerBlocks = [
      {
        type: 'Bullish Breaker',
        timeframe: 'H4',
        level: (price - 0.0030).toFixed(5),
        strength: 'High',
        description: 'Previous resistance turned support'
      },
      {
        type: 'Bearish Breaker',
        timeframe: 'H1',
        level: (price + 0.0035).toFixed(5),
        strength: 'Medium',
        description: 'Previous support turned resistance'
      }
    ];

    // Liquidity Zones
    poi.liquidityZones = [
      {
        type: 'Buy Side Liquidity',
        timeframe: 'D1',
        level: (price + 0.0050).toFixed(5),
        description: 'Above previous highs, target for smart money'
      },
      {
        type: 'Sell Side Liquidity',
        timeframe: 'D1',
        level: (price - 0.0040).toFixed(5),
        description: 'Below previous lows, target for smart money'
      }
    ];

    // Fibonacci Levels (simplified for example)
    const fibLevels = [0.236, 0.382, 0.5, 0.618, 0.786];
    poi.fibonacciLevels = fibLevels.map(level => ({
      level: (price * (1 + (level - 0.5) * 0.01)).toFixed(5), // Placeholder calculation
      percentage: `${(level * 100).toFixed(1)}%`
    }));

    return poi;
  };

  // Fetch data from Alpha Vantage
  const fetchData = async (pair) => {
    setLoading(true);
    try {
      const symbol = pair.replace('/', '');
      const response = await fetch(`${ALPHA_VANTAGE_BASE_URL}?function=CURRENCY_EXCHANGE_RATE&from_currency=${symbol.substring(0, 3)}&to_currency=${symbol.substring(3, 6)}&apikey=${ALPHA_VANTAGE_API_KEY}`);
      const data = await response.json();

      if (data['Realtime Currency Exchange Rate']) {
        const rate = parseFloat(data['Realtime Currency Exchange Rate']['5. Exchange Rate']);
        setCurrentPrice(rate.toFixed(5));
        setLastUpdate(new Date());

        // Simulate advanced analysis based on real-time price
        const poiData = analyzePOI(rate, 'H1'); // Example timeframe
        setTechnicalAnalysis({
          marketStructure: {
            htfBias: 'Bullish', // Example
            structure: 'BOS (Break of Structure)', // Example
            amdxPhase: 'Expansion', // Example
            trend: 'Uptrend', // Example
            strength: 'Strong' // Example
          },
          keyLevels: {
            currentPrice: rate.toFixed(5),
            sma20: (rate - 0.0005).toFixed(5),
            sma50: (rate - 0.0010).toFixed(5),
            support: (rate - 0.0020).toFixed(5),
            resistance: (rate + 0.0025).toFixed(5)
          },
          indicators: {
            rsi: Math.floor(Math.random() * (80 - 20 + 1)) + 20, // Random RSI
            macd: 'Bullish Crossover', // Example
            ema: 'Price Above 20 EMA', // Example
            volume: 'Normal', // Example
            momentum: 'Strong'
          },
          poi: poiData
        });

        // Simulate signals based on analysis
        setSignals([
          {
            id: 1,
            pair: pair,
            type: 'BUY',
            confidence: '88%',
            status: 'Active',
            entry: rate.toFixed(5),
            sl: (rate - 0.0020).toFixed(5),
            tp: (rate + 0.0040).toFixed(5),
            rr: '1:2',
            setup: 'RSI Oversold + Bullish OB',
            analysis: 'RSI at 23 indicates oversold condition. Price reacting from Bullish Order Block.'
          },
          {
            id: 2,
            pair: pair,
            type: 'SELL',
            confidence: '75%',
            status: 'Pending',
            entry: (rate + 0.0010).toFixed(5),
            sl: (rate + 0.0030).toFixed(5),
            tp: (rate - 0.0020).toFixed(5),
            rr: '1:1.5',
            setup: 'Bearish FVG + Resistance',
            analysis: 'Price approaching Bearish FVG and strong resistance level. Waiting for confirmation.'
          }
        ]);

        // Simulate fundamental analysis
        setFundamentalAnalysis({
          marketSentiment: 'Risk On',
          currencyStrength: {
            base: 'Strong',
            quote: 'Weak'
          },
          keyMarketFactors: [
            'Inflation data better than expected',
            'Central bank hawkish comments',
            'Geopolitical tensions easing',
            'Strong corporate earnings',
            'Commodity prices stabilizing'
          ],
          marketOverview: 'Global markets show risk-on sentiment, with strong performance in equities and commodities. Central banks maintain hawkish stance on inflation. '
        });

        // Simulate economic calendar
        setEconomicCalendar([
          {
            id: 1,
            time: '15:30',
            currency: 'USD',
            event: 'Non-Farm Payrolls',
            impact: 'High',
            forecast: '180K',
            previous: '150K'
          },
          {
            id: 2,
            time: '14:00',
            currency: 'EUR',
            event: 'ECB Interest Rate Decision',
            impact: 'High',
            forecast: '2.50%',
            previous: '2.25%'
          },
          {
            id: 3,
            time: '10:00',
            currency: 'GBP',
            event: 'CPI Data',
            impact: 'Medium',
            forecast: '6.5%',
            previous: '6.2%'
          },
          {
            id: 4,
            time: '08:30',
            currency: 'JPY',
            event: 'BoJ Press Conference',
            impact: 'High',
            forecast: 'Hawkish',
            previous: 'Neutral'
          }
        ]);

      } else {
        console.error('Error fetching data:', data);
        setCurrentPrice('N/A');
      }
    } catch (error) {
      console.error('Network or API error:', error);
      setCurrentPrice('Error');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData(currentPair);
    const interval = setInterval(() => fetchData(currentPair), 300000); // Refresh every 5 minutes
    return () => clearInterval(interval);
  }, [currentPair]);

  // Push Notification Logic
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'granted') {
      signals.forEach(signal => {
        if (signal.status === 'Active') {
          new Notification(`🎯 ${signal.type} ${signal.pair} Signal!`, {
            body: `Entry: ${signal.entry}, SL: ${signal.sl}, TP: ${signal.tp}. Setup: ${signal.setup}`,
            icon: '/favicon.ico',
            badge: '/favicon.ico'
          });
        }
      });
    }
  }, [signals]);

  return (
    <div className={`min-h-screen flex ${isDarkMode ? 'bg-gray-900 text-gray-100' : 'bg-gray-100 text-gray-900'}`}>
      {/* Sidebar */}
      <aside className={`w-64 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} p-6 border-r ${isDarkMode ? 'border-gray-700' : 'border-gray-200'} flex flex-col`}>
        <div className="flex items-center mb-8">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg mr-3">
            TS
          </div>
          <h1 className="text-2xl font-bold">Trading Signal Pro</h1>
        </div>

        {/* Pair Navigation */}
        <nav className="flex-grow">
          {Object.entries(TRADING_PAIRS).map(([category, pairs]) => (
            <div key={category} className="mb-6">
              <h2 className={`text-xs font-semibold uppercase tracking-wider mb-3 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {category}
              </h2>
              <ul>
                {pairs.map(pair => (
                  <li key={pair} className="mb-2">
                    <button
                      onClick={() => setCurrentPair(pair)}
                      className={`w-full text-left px-4 py-2 rounded-lg transition-colors duration-200 ${
                        currentPair === pair
                          ? 'bg-blue-600 text-white shadow-md'
                          : `${isDarkMode ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-100 text-gray-700'}`
                      }`}
                    >
                      {pair}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        {/* Creator Info */}
        <div className={`mt-8 pt-6 border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-2`}>
            Created by <span className="font-semibold">Mulky Malikul Dhaher</span>
          </p>
          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'} mb-2`}>
            Contact: <a href="mailto:mulkymalikuldhr@mail.com" className="text-blue-500 hover:underline">mulkymalikuldhr@mail.com</a>
          </p>
          <div className="flex space-x-3 mb-4">
            {SOCIAL_MEDIA.map(social => (
              <a 
                key={social.name} 
                href={social.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-lg ${social.color} hover:opacity-80 transition-opacity`}
                title={social.name}
              >
                {social.icon}
              </a>
            ))}
          </div>
          <p className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-400'}`}>&copy; {new Date().getFullYear()} Trading Signal Pro. All rights reserved.</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto">
        {/* Header */}
        <header className={`flex justify-between items-center pb-6 border-b ${isDarkMode ? 'border-gray-700' : 'border-gray-200'} mb-6`}>
          <h2 className="text-3xl font-bold">{currentPair}</h2>
          <div className="flex items-center space-x-4">
            <span className={`text-lg font-semibold ${loading ? 'text-yellow-500' : 'text-green-500'}`}>
              {loading ? 'Updating...' : `Live Market ${currentPrice}`}
            </span>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-800'} transition-colors duration-200`}
              title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDarkMode ? '☀️' : '🌙'}
            </button>
          </div>
        </header>

        {/* Market Sessions */}
        <div className="mb-6">
          <MarketSessionStatus isDarkMode={isDarkMode} />
        </div>

        {/* TradingView Chart */}
        <div className="mb-6">
          <TradingViewWidget symbol={currentPair} isDarkMode={isDarkMode} />
        </div>

        {/* Tabs for Signals, Technical, Fundamental, Calendar */}
        <div className={`bg-gray-800 rounded-lg p-4 mb-6`}>
          <div className="flex border-b border-gray-700 mb-4">
            <button
              onClick={() => setCurrentTab('signals')}
              className={`px-4 py-2 text-sm font-medium ${currentTab === 'signals' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-400 hover:text-gray-200'}`}
            >
              🎯 Signals ({signals.length})
            </button>
            <button
              onClick={() => setCurrentTab('technical')}
              className={`ml-4 px-4 py-2 text-sm font-medium ${currentTab === 'technical' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-400 hover:text-gray-200'}`}
            >
              📊 Technical Analysis
            </button>
            <button
              onClick={() => setCurrentTab('fundamental')}
              className={`ml-4 px-4 py-2 text-sm font-medium ${currentTab === 'fundamental' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-400 hover:text-gray-200'}`}
            >
              📰 Fundamental Analysis
            </button>
            <button
              onClick={() => setCurrentTab('calendar')}
              className={`ml-4 px-4 py-2 text-sm font-medium ${currentTab === 'calendar' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-400 hover:text-gray-200'}`}
            >
              📅 Economic Calendar ({economicCalendar.length})
            </button>
          </div>

          {/* Tab Content */}
          <div>
            {currentTab === 'signals' && (
              <div>
                <h3 className="text-xl font-semibold mb-4">Active Trading Signals</h3>
                {signals.length === 0 ? (
                  <p className="text-gray-400">No active signals for {currentPair} at the moment.</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {signals.map(signal => (
                      <div key={signal.id} className="bg-gray-700 p-4 rounded-lg shadow-md">
                        <div className="flex justify-between items-center mb-2">
                          <span className={`text-lg font-bold ${signal.type === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>{signal.type} {signal.pair}</span>
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${signal.status === 'Active' ? 'bg-green-500' : 'bg-yellow-500'} text-white`}>{signal.status}</span>
                        </div>
                        <p className="text-sm text-gray-300 mb-1">Confidence: {signal.confidence}</p>
                        <p className="text-sm text-gray-300 mb-1">Entry: {signal.entry}</p>
                        <p className="text-sm text-gray-300 mb-1">SL: {signal.sl}, TP: {signal.tp}</p>
                        <p className="text-sm text-gray-300 mb-2">R:R: {signal.rr}</p>
                        <p className="text-sm font-semibold text-gray-200">Setup: {signal.setup}</p>
                        <p className="text-xs text-gray-400">Analysis: {signal.analysis}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {currentTab === 'technical' && (
              <div>
                <h3 className="text-xl font-semibold mb-4">Technical Analysis - {currentPair}</h3>
                {technicalAnalysis.marketStructure && (
                  <div className="space-y-4">
                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Market Structure</h4>
                      <p className="text-sm text-gray-300">HTF Bias: {technicalAnalysis.marketStructure.htfBias}</p>
                      <p className="text-sm text-gray-300">Structure: {technicalAnalysis.marketStructure.structure}</p>
                      <p className="text-sm text-gray-300">AMDX Phase: {technicalAnalysis.marketStructure.amdxPhase}</p>
                      <p className="text-sm text-gray-300">Trend: {technicalAnalysis.marketStructure.trend}</p>
                      <p className="text-sm text-gray-300">Strength: {technicalAnalysis.marketStructure.strength}</p>
                    </div>

                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Key Levels</h4>
                      <p className="text-sm text-gray-300">Current Price: {technicalAnalysis.keyLevels.currentPrice}</p>
                      <p className="text-sm text-gray-300">SMA20: {technicalAnalysis.keyLevels.sma20}</p>
                      <p className="text-sm text-gray-300">SMA50: {technicalAnalysis.keyLevels.sma50}</p>
                      <p className="text-sm text-gray-300">Support: {technicalAnalysis.keyLevels.support}</p>
                      <p className="text-sm text-gray-300">Resistance: {technicalAnalysis.keyLevels.resistance}</p>
                    </div>

                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Indicators</h4>
                      <p className="text-sm text-gray-300">RSI: {technicalAnalysis.indicators.rsi}</p>
                      <p className="text-sm text-gray-300">MACD: {technicalAnalysis.indicators.macd}</p>
                      <p className="text-sm text-gray-300">EMA: {technicalAnalysis.indicators.ema}</p>
                      <p className="text-sm text-gray-300">Volume: {technicalAnalysis.indicators.volume}</p>
                      <p className="text-sm text-gray-300">Momentum: {technicalAnalysis.indicators.momentum}</p>
                    </div>

                    {/* POI Display */}
                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Points of Interest (POI)</h4>
                      
                      {/* Order Blocks */}
                      <h5 className="text-md font-semibold mt-4 mb-2 text-blue-400">Order Blocks</h5>
                      {technicalAnalysis.poi.orderBlocks.length > 0 ? (
                        technicalAnalysis.poi.orderBlocks.map((ob, index) => (
                          <div key={index} className="mb-2 text-sm text-gray-300">
                            <p>{ob.type} ({ob.timeframe}): {ob.level} - Strength: {ob.strength}, Validity: {ob.validity}</p>
                            <p className="ml-4">Entry Zone: {ob.entryZone}</p>
                            <p className="ml-4">Invalidation: {ob.invalidation}</p>
                            <p className="ml-4">Confluence: {ob.confluence.join(', ')}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-400">No Order Blocks identified.</p>
                      )}

                      {/* Fair Value Gaps */}
                      <h5 className="text-md font-semibold mt-4 mb-2 text-green-400">Fair Value Gaps</h5>
                      {technicalAnalysis.poi.fairValueGaps.length > 0 ? (
                        technicalAnalysis.poi.fairValueGaps.map((fvg, index) => (
                          <div key={index} className="mb-2 text-sm text-gray-300">
                            <p>{fvg.type} ({fvg.timeframe}): {fvg.high} - {fvg.low} - Status: {fvg.filled ? 'Filled' : 'Open'}</p>
                            <p className="ml-4">Strength: {fvg.strength}, Confluence: {fvg.confluence.join(', ')}</p>
                            <p className="ml-4">Description: {fvg.description}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-400">No Fair Value Gaps identified.</p>
                      )}

                      {/* Breaker Blocks */}
                      <h5 className="text-md font-semibold mt-4 mb-2 text-red-400">Breaker Blocks</h5>
                      {technicalAnalysis.poi.breakerBlocks.length > 0 ? (
                        technicalAnalysis.poi.breakerBlocks.map((bb, index) => (
                          <div key={index} className="mb-2 text-sm text-gray-300">
                            <p>{bb.type} ({bb.timeframe}): {bb.level} - Strength: {bb.strength}</p>
                            <p className="ml-4">Description: {bb.description}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-400">No Breaker Blocks identified.</p>
                      )}

                      {/* Liquidity Zones */}
                      <h5 className="text-md font-semibold mt-4 mb-2 text-yellow-400">Liquidity Zones</h5>
                      {technicalAnalysis.poi.liquidityZones.length > 0 ? (
                        technicalAnalysis.poi.liquidityZones.map((lz, index) => (
                          <div key={index} className="mb-2 text-sm text-gray-300">
                            <p>{lz.type} ({lz.timeframe}): {lz.level}</p>
                            <p className="ml-4">Description: {lz.description}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-400">No Liquidity Zones identified.</p>
                      )}

                      {/* Fibonacci Levels */}
                      <h5 className="text-md font-semibold mt-4 mb-2 text-purple-400">Fibonacci Levels</h5>
                      {technicalAnalysis.poi.fibonacciLevels.length > 0 ? (
                        technicalAnalysis.poi.fibonacciLevels.map((fib, index) => (
                          <p key={index} className="mb-1 text-sm text-gray-300">{fib.percentage}: {fib.level}</p>
                        ))
                      ) : (
                        <p className="text-sm text-gray-400">No Fibonacci Levels identified.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {currentTab === 'fundamental' && (
              <div>
                <h3 className="text-xl font-semibold mb-4">Fundamental Analysis - {currentPair}</h3>
                {fundamentalAnalysis.marketSentiment && (
                  <div className="space-y-4">
                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Market Sentiment</h4>
                      <p className="text-sm text-gray-300">Sentiment: {fundamentalAnalysis.marketSentiment}</p>
                      <p className="text-sm text-gray-300">Currency Strength (Base): {fundamentalAnalysis.currencyStrength.base}</p>
                      <p className="text-sm text-gray-300">Currency Strength (Quote): {fundamentalAnalysis.currencyStrength.quote}</p>
                    </div>

                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Key Market Factors</h4>
                      <ul className="list-disc list-inside text-sm text-gray-300">
                        {fundamentalAnalysis.keyMarketFactors.map((factor, index) => (
                          <li key={index}>{factor}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-gray-700 p-4 rounded-lg shadow-md">
                      <h4 className="text-lg font-semibold mb-2">Market Overview</h4>
                      <p className="text-sm text-gray-300">{fundamentalAnalysis.marketOverview}</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {currentTab === 'calendar' && (
              <div>
                <h3 className="text-xl font-semibold mb-4">Economic Calendar</h3>
                {economicCalendar.length === 0 ? (
                  <p className="text-gray-400">No upcoming economic events.</p>
                ) : (
                  <div className="space-y-4">
                    {economicCalendar.map(event => (
                      <div key={event.id} className="bg-gray-700 p-4 rounded-lg shadow-md">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-lg font-bold text-gray-100">{event.event}</span>
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${event.impact === 'High' ? 'bg-red-500' : event.impact === 'Medium' ? 'bg-yellow-500' : 'bg-green-500'} text-white`}>{event.impact} Impact</span>
                        </div>
                        <p className="text-sm text-gray-300 mb-1">Time: {event.time} ({event.currency})</p>
                        <p className="text-sm text-gray-300 mb-1">Forecast: {event.forecast}</p>
                        <p className="text-sm text-gray-300">Previous: {event.previous}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Visitor Notes */}
        <div className="mb-6">
          <VisitorNotes isDarkMode={isDarkMode} />
        </div>

        {/* Donation Section */}
        <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg p-4 border ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <h3 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
            💖 Support Us
          </h3>
          <p className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-700'} mb-4`}>
            If you find this tool useful, consider making a donation to support its development and maintenance. Your support is greatly appreciated!
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {DONATION_WALLETS.map(wallet => (
              <a 
                key={wallet.name} 
                href={wallet.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className={`flex flex-col items-center justify-center p-4 rounded-lg shadow-md transition-transform transform hover:scale-105 ${wallet.color} text-white`}
              >
                <span className="text-4xl mb-2">{wallet.logo}</span>
                <span className="text-sm font-semibold">{wallet.name}</span>
              </a>
            ))}
            {/* PayPal for international donations */}
            <a 
              href="https://paypal.me/mulkymalikuldhr" 
              target="_blank" 
              rel="noopener noreferrer"
              className={`flex flex-col items-center justify-center p-4 rounded-lg shadow-md transition-transform transform hover:scale-105 bg-blue-700 text-white`}
            >
              <span className="text-4xl mb-2">🅿️</span>
              <span className="text-sm font-semibold">PayPal</span>
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;


