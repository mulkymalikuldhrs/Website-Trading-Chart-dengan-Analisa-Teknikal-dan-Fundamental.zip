# Persyaratan Website Trading Chart

Berdasarkan analisis kedua dokumen trading plan, berikut adalah persyaratan fungsional dan non-fungsional untuk website trading chart:

## Fungsionalitas Utama:

1.  **Tampilan Trading Chart:**
    *   Menampilkan chart untuk semua mata uang (forex) dan cryptocurrency.
    *   Mendukung analisis multi-timeframe (Monthly, Weekly, Daily, H4, H1, M30, M15, M5, M1, S15).
    *   Menampilkan sesi pasar (Asia, London, New York) dan Killzone (London, New York, Asian).
    *   Menampilkan ICT Macro Times.

2.  **Indikator Berdasarkan Trading Plan:**
    *   **Market Structure:** BOS (Break of Structure), CHoCH (Change of Character).
    *   **Point of Interest (POI):** Order Block (OB), Fair Value Gap (FVG), Breaker Block (BB).
    *   **Liquidity Analysis:** External Liquidity (PDH/PDL, PWH/PWL, PMH/PML, Session High/Low, Round Numbers, Previous Structure Points), Internal Liquidity (Equal Highs/Lows, Trendline Liquidity, Support/Resistance Levels, Fibonacci Levels, Moving Average Levels, Psychological Levels).
    *   **AMDX Cycle:** Accumulation, Manipulation, Distribution, Redistribution Phases.
    *   **AI Enhancement:** Neural Networks, Sentiment Analysis, Pattern Recognition (Candlestick Patterns, Chart Patterns, Elliott Wave, Fibonacci, Custom Patterns).

3.  **Analisa Teknikal:**
    *   Visualisasi indikator-indikator di atas pada chart.
    *   Identifikasi otomatis pola-pola seperti BOS, CHoCH, OB, FVG, BB, Liquidity Sweeps.

4.  **Analisa Fundamental:**
    *   Integrasi kalender ekonomi (High Impact News, Medium Impact News).
    *   Analisis sentimen pasar (news sentiment, social media, COT data, VIX, yield curves, crypto correlation).
    *   Menampilkan dampak berita pada pair mata uang.

5.  **Sinyal Trading:**
    *   Menampilkan titik entry, Take Profit (TP), dan Stop Loss (SL) berdasarkan 


trading plan (One Setup for Life 2.0).
    *   Sinyal harus mencakup:
        *   Pasangan mata uang/kripto.
        *   Arah (Buy/Sell).
        *   Entry Price.
        *   Stop Loss (SL).
        *   Take Profit (TP) - minimal 1:2 RRR, dengan potensi partial profit pada 1:2 dan 1:4.
        *   Kondisi filter (Spread, Volatility, News impact, Account drawdown, Daily trade limit).

6.  **Multi-Market Analysis:**
    *   Dukungan untuk Major Pairs, Cross Pairs, Exotic Pairs.
    *   Dukungan untuk Komoditas (Precious Metals, Energy, Agricultural).

## Persyaratan Non-Fungsional:

1.  **Kesederhanaan dan Kualitas:** Website harus sesederhana mungkin namun sebaik mungkin, menyerupai web signal trading.
2.  **Monitoring Chart:** Kemampuan untuk memonitor chart secara real-time.
3.  **Visualisasi Indikator dan Sinyal:** Indikator dan sinyal harus divisualisasikan dengan jelas pada chart.
4.  **Responsif:** Kompatibel dengan perangkat desktop dan mobile.
5.  **Keamanan:** Data pengguna dan koneksi harus aman.
6.  **Kecepatan:** Loading chart dan data harus cepat.

## Data yang Dibutuhkan:

*   Data harga historis dan real-time untuk berbagai pasangan mata uang dan kripto.
*   Data kalender ekonomi.
*   Data sentimen pasar (jika tersedia melalui API).

## Teknologi yang Mungkin Digunakan (akan diteliti lebih lanjut):

*   **Frontend:** React (berdasarkan utility `manus-create-react-app`).
*   **Chart Library:** TradingView Charting Library, Lightweight Charts, atau sejenisnya.
*   **Data API:** Penyedia data pasar real-time (misalnya, Alpha Vantage, Finnhub, Twelve Data, Binance API untuk kripto).
*   **Backend (opsional, jika diperlukan untuk logika sinyal kompleks atau data):** Flask (berdasarkan utility `manus-create-flask-app`).



