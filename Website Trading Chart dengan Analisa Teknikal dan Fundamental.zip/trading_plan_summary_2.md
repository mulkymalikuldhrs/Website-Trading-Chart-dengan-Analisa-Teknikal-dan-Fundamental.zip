
### Ringkasan TRADING_PLAN_ULTIMATE_EBOOK.txt

Dokumen ini berjudul "MASTERING TRADING: Panduan Lengkap & Trading Plan Ultimate" yang disusun oleh Mulky Malikul Dhaher dan dilengkapi oleh Manus AI. Ini adalah panduan komprehensif untuk menguasai dunia trading, dengan fokus pada aplikasi praktis. Berikut adalah poin-poin penting yang relevan untuk pengembangan website:

**1. Metode & Pasangan Timeframe:**
*   **Metode Utama:** ICT (Inner Circle Trader), SMC (Smart Money Concepts), MSNR (Market Structure, Supply and Demand, and Reversal), SnD (Supply and Demand), One Setup for Life, AMDX (Accumulation, Manipulation, Distribution, eXtension), Quarterly Theory, News Analysis.
*   **Pasangan Timeframe:** HTF (Higher Timeframe) - Bias & Struktur (H4), MTF (Mid-Timeframe) - POI & Narasi (H1/M15), LTF (Lower Timeframe) - Entry Eksekusi (M5/M1).
*   **Indikator Kunci:** Tren, Support/Resistance, Area Likuiditas, Order Blocks, Fair Value Gaps, Aliran Order, Change of Character (CHoCH), Break of Structure (BOS).

**2. Waktu & Sesi (Killzone + Macro Time):**
*   **Sesi Trading Utama:** Asia Session (Tokyo), London Session (Eropa), New York Session (Amerika).
*   **Killzone:** London Killzone (14:00–17:00 WIB), New York Killzone (19:00–22:00 WIB).
*   **ICT Macro Time:** Periode waktu sempit (contoh: 20:50–21:10 WIB, 21:50–22:10 WIB) di mana pergerakan harga besar dan manipulasi Smart Money sering terjadi.
*   **Zona Berisiko Tinggi (Entry Sensitive):** 11:30–12:30 WIB (hindari entry).

**3. Market Structure & AMDX Cycle:**
*   **Struktur Pasar Utama:** BOS (Break of Structure) dan CHoCH (Change of Character) untuk mengidentifikasi kelanjutan atau pembalikan tren. Penembusan harus dengan penutupan body candle.
*   **AMDX Cycle:** Accumulation, Manipulation, Distribution, eXtension – siklus pasar yang menggambarkan operasi Smart Money.

(Konten terpotong karena batasan ukuran. Gunakan rentang baris untuk membaca dalam potongan)

