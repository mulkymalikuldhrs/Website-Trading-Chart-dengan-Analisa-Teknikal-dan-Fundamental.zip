# API Keys dan Konfigurasi

## Alpha Vantage API
- API Key: I8HZZ5CRDBQG6IPT
- Base URL: https://www.alphavantage.co/query
- Rate Limit: 25 requests per day (free tier)

## Endpoints yang akan digunakan:
1. FX_DAILY - Daily forex rates
2. FX_INTRADAY - Intraday forex rates  
3. CURRENCY_EXCHANGE_RATE - Real-time exchange rates
4. NEWS_SENTIMENT - Market news and sentiment
5. ECONOMIC_INDICATORS - Economic data

## Forex Factory (Web Scraping)
- URL: https://www.forexfactory.com/calendar
- Economic calendar data

## Investing.com (Web Scraping)
- URL: https://www.investing.com/economic-calendar/
- Economic events and market data

