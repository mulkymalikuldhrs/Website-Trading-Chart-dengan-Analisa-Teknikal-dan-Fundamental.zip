// Trading Signal Pro - JavaScript Application

// Mock data untuk demo
const mockSignals = [
    {
        id: 1,
        pair: 'EUR/USD',
        type: 'BUY',
        entry: 1.0850,
        sl: 1.0830,
        tp: 1.0890,
        rr: '1:2',
        confidence: 85,
        setup: 'Order Block + FVG',
        status: 'active',
        reasoning: 'HTF bullish bias confirmed with BOS. Price reacted from premium OB zone with confluence of FVG. London killzone timing optimal.'
    },
    {
        id: 2,
        pair: 'GBP/USD',
        type: 'SELL',
        entry: 1.2650,
        sl: 1.2670,
        tp: 1.2610,
        rr: '1:2',
        confidence: 78,
        setup: 'Liquidity Sweep + CHoCH',
        status: 'active',
        reasoning: 'Liquidity sweep above previous high followed by CHoCH bearish. AMDX in distribution phase. NY session manipulation detected.'
    },
    {
        id: 3,
        pair: 'USD/JPY',
        type: 'BUY',
        entry: 149.50,
        sl: 149.20,
        tp: 150.10,
        rr: '1:2',
        confidence: 72,
        setup: 'BOS + Support Zone',
        status: 'pending',
        reasoning: 'Waiting for BOS confirmation above 149.60. Strong support zone confluence with 50% FVG fill. Risk-on sentiment supporting JPY weakness.'
    }
];

const mockTechnicalAnalysis = {
    'EUR/USD': {
        marketStructure: {
            htfBias: 'Bullish',
            structure: 'BOS Confirmed',
            amdxPhase: 'Distribution',
            trend: 'Uptrend',
            strength: 'Strong'
        },
        keyLevels: {
            orderBlock: '1.0845-1.0855',
            fvg: '1.0860-1.0865',
            liquidity: '1.0880 (PDH)',
            support: '1.0820',
            resistance: '1.0890'
        },
        indicators: {
            rsi: 65,
            macd: 'Bullish Crossover',
            ema: 'Above 20/50 EMA',
            volume: 'Above Average',
            momentum: 'Strong'
        },
        sessionAnalysis: {
            asia: 'Accumulation - Range bound between 1.0840-1.0860',
            london: 'Manipulation - False breakout below 1.0840, then recovery',
            newYork: 'Distribution - Strong move to 1.0880, now consolidating'
        }
    },
    'GBP/USD': {
        marketStructure: {
            htfBias: 'Bearish',
            structure: 'CHoCH Confirmed',
            amdxPhase: 'Manipulation',
            trend: 'Downtrend',
            strength: 'Moderate'
        },
        keyLevels: {
            orderBlock: '1.2640-1.2650',
            fvg: '1.2620-1.2625',
            liquidity: '1.2680 (PWH)',
            support: '1.2600',
            resistance: '1.2680'
        },
        indicators: {
            rsi: 35,
            macd: 'Bearish Divergence',
            ema: 'Below 20/50 EMA',
            volume: 'High on Sell-offs',
            momentum: 'Weak'
        },
        sessionAnalysis: {
            asia: 'Consolidation - Tight range, low volatility',
            london: 'Manipulation - Liquidity sweep above 1.2680',
            newYork: 'Distribution - Sharp decline to 1.2620 support'
        }
    }
};

const mockFundamentalAnalysis = {
    marketSentiment: {
        overall: 'Risk On',
        vix: 18.5,
        dxy: 'Consolidating',
        yields: 'Rising',
        crypto: 'Bullish'
    },
    currencyStrength: {
        USD: { strength: 'Moderate', outlook: 'Neutral', score: 6.5 },
        EUR: { strength: 'Weak', outlook: 'Bearish', score: 4.2 },
        GBP: { strength: 'Very Weak', outlook: 'Bearish', score: 3.8 },
        JPY: { strength: 'Weak', outlook: 'Bearish', score: 4.0 }
    },
    keyFactors: [
        'ECB rate decision pending - dovish bias expected',
        'US employment data strong - supporting USD',
        'EU inflation concerns persist',
        'BoE policy uncertainty weighing on GBP',
        'BoJ intervention threats limiting JPY weakness'
    ]
};

const mockNews = [
    {
        id: 1,
        time: '15:30',
        currency: 'USD',
        event: 'Non-Farm Payrolls',
        impact: 'high',
        forecast: '180K',
        previous: '150K',
        description: 'Monthly change in employment excluding farm workers'
    },
    {
        id: 2,
        time: '16:00',
        currency: 'EUR',
        event: 'ECB Interest Rate Decision',
        impact: 'high',
        forecast: '4.25%',
        previous: '4.25%',
        description: 'European Central Bank monetary policy decision'
    },
    {
        id: 3,
        time: '17:30',
        currency: 'GBP',
        event: 'GDP Growth Rate',
        impact: 'medium',
        forecast: '0.2%',
        previous: '0.1%',
        description: 'Quarterly gross domestic product growth'
    }
];

// Global variables
let chart;
let candlestickSeries;
let currentPair = 'EUR/USD';
let currentTab = 'signals';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupEventListeners();
    initializeChart();
    renderSidebar();
    renderSignals();
    renderTechnicalAnalysis();
    renderFundamentalAnalysis();
    renderCalendar();
    updateTime();
    setInterval(updateTime, 1000);
}

function setupEventListeners() {
    // Pair selector
    document.getElementById('pairSelector').addEventListener('change', function(e) {
        currentPair = e.target.value;
        updateChart();
        updateAnalysis();
    });

    // Tab buttons
    document.querySelectorAll('.tab-button').forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            switchTab(tabId);
        });
    });

    // Timeframe buttons
    document.querySelectorAll('.tf-button').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('.tf-button').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            updateChart();
        });
    });
}

function renderSidebar() {
    const majorPairs = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'USD/CHF', 'AUD/USD', 'USD/CAD', 'NZD/USD'];
    const cryptoPairs = ['BTC/USD', 'ETH/USD', 'XRP/USD', 'ADA/USD'];

    const majorContainer = document.getElementById('majorPairs');
    const cryptoContainer = document.getElementById('cryptoPairs');

    majorPairs.forEach(pair => {
        const button = createPairButton(pair);
        majorContainer.appendChild(button);
    });

    cryptoPairs.forEach(pair => {
        const button = createPairButton(pair);
        cryptoContainer.appendChild(button);
    });
}

function createPairButton(pair) {
    const button = document.createElement('button');
    button.className = `pair-button ${pair === currentPair ? 'active' : ''}`;
    button.textContent = pair;
    button.addEventListener('click', function() {
        document.querySelectorAll('.pair-button').forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        currentPair = pair;
        document.getElementById('pairSelector').value = pair;
        updateChart();
        updateAnalysis();
    });
    return button;
}

function initializeChart() {
    const chartContainer = document.getElementById('chart');
    
    chart = LightweightCharts.createChart(chartContainer, {
        layout: {
            background: { type: LightweightCharts.ColorType.Solid, color: '#1f2937' },
            textColor: '#d1d5db',
        },
        grid: {
            vertLines: { color: '#374151' },
            horzLines: { color: '#374151' },
        },
        crosshair: {
            mode: LightweightCharts.CrosshairMode.Normal,
        },
        rightPriceScale: {
            borderColor: '#4b5563',
        },
        timeScale: {
            borderColor: '#4b5563',
            timeVisible: true,
            secondsVisible: false,
        },
        width: chartContainer.clientWidth,
        height: 400,
    });

    candlestickSeries = chart.addCandlestickSeries({
        upColor: '#10b981',
        downColor: '#ef4444',
        borderDownColor: '#ef4444',
        borderUpColor: '#10b981',
        wickDownColor: '#ef4444',
        wickUpColor: '#10b981',
    });

    // Generate and set mock data
    const mockData = generateMockData();
    candlestickSeries.setData(mockData);

    // Handle resize
    window.addEventListener('resize', () => {
        chart.applyOptions({ width: chartContainer.clientWidth });
    });
}

function generateMockData() {
    const data = [];
    let basePrice = 1.0850;
    const now = new Date();
    
    for (let i = 100; i >= 0; i--) {
        const time = Math.floor((now.getTime() - i * 60 * 1000) / 1000);
        const change = (Math.random() - 0.5) * 0.002;
        basePrice += change;
        
        const open = basePrice;
        const high = open + Math.random() * 0.001;
        const low = open - Math.random() * 0.001;
        const close = low + Math.random() * (high - low);
        
        data.push({
            time,
            open: parseFloat(open.toFixed(5)),
            high: parseFloat(high.toFixed(5)),
            low: parseFloat(low.toFixed(5)),
            close: parseFloat(close.toFixed(5))
        });
        
        basePrice = close;
    }
    
    return data;
}

function updateChart() {
    document.getElementById('chartTitle').textContent = currentPair;
    const mockData = generateMockData();
    candlestickSeries.setData(mockData);
}

function updateAnalysis() {
    document.getElementById('technicalPair').textContent = currentPair;
    renderTechnicalAnalysis();
}

function switchTab(tabId) {
    // Update tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');

    // Update tab panels
    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.add('hidden'));
    document.getElementById(`${tabId}-tab`).classList.remove('hidden');

    currentTab = tabId;
}

function renderSignals() {
    const container = document.getElementById('signalsContainer');
    container.innerHTML = '';

    mockSignals.forEach(signal => {
        const signalCard = createSignalCard(signal);
        container.appendChild(signalCard);
    });
}

function createSignalCard(signal) {
    const isLong = signal.type === 'BUY';
    
    const card = document.createElement('div');
    card.className = 'signal-card';
    
    card.innerHTML = `
        <div class="signal-header">
            <div class="signal-type">
                <span class="badge ${isLong ? 'badge-green' : ''}" style="background-color: ${isLong ? '#22c55e' : '#ef4444'}; color: white; padding: 0.25rem 0.75rem;">
                    ${isLong ? '📈' : '📉'} ${signal.type}
                </span>
                <span class="signal-pair">${signal.pair}</span>
            </div>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <span class="signal-confidence">${signal.confidence}% Confidence</span>
                <span class="badge" style="background-color: ${signal.status === 'active' ? 'rgba(34, 197, 94, 0.2)' : 'rgba(234, 179, 8, 0.2)'}; color: ${signal.status === 'active' ? '#22c55e' : '#eab308'}; font-size: 0.75rem;">
                    ${signal.status}
                </span>
            </div>
        </div>
        
        <div class="signal-levels">
            <div class="signal-level">
                <span class="signal-level-label">Entry</span>
                <div class="signal-level-value" style="color: white;">${signal.entry}</div>
            </div>
            <div class="signal-level">
                <span class="signal-level-label">Stop Loss</span>
                <div class="signal-level-value" style="color: #ef4444;">${signal.sl}</div>
            </div>
            <div class="signal-level">
                <span class="signal-level-label">Take Profit</span>
                <div class="signal-level-value" style="color: #22c55e;">${signal.tp}</div>
            </div>
            <div class="signal-level">
                <span class="signal-level-label">Risk:Reward</span>
                <div class="signal-level-value" style="color: #3b82f6;">${signal.rr}</div>
            </div>
        </div>
        
        <div class="signal-setup">
            <div style="margin-bottom: 0.5rem;">
                <span class="signal-setup-label">Setup: </span>
                <span class="signal-setup-value">${signal.setup}</span>
            </div>
            <div style="font-size: 0.75rem; color: #d1d5db; line-height: 1.4;">
                <span class="signal-setup-label">Analysis: </span>
                ${signal.reasoning}
            </div>
        </div>
    `;
    
    return card;
}

function renderTechnicalAnalysis() {
    const analysis = mockTechnicalAnalysis[currentPair] || mockTechnicalAnalysis['EUR/USD'];
    const container = document.getElementById('technicalAnalysis');
    
    container.innerHTML = `
        <div class="analysis-grid">
            <div class="analysis-card">
                <h4>🏗️ Market Structure</h4>
                <div class="analysis-item">
                    <span class="analysis-label">HTF Bias:</span>
                    <span class="badge" style="background-color: ${analysis.marketStructure.htfBias === 'Bullish' ? '#22c55e' : '#ef4444'}; color: white; font-size: 0.75rem; padding: 0.25rem 0.5rem;">
                        ${analysis.marketStructure.htfBias}
                    </span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Structure:</span>
                    <span class="analysis-value">${analysis.marketStructure.structure}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">AMDX Phase:</span>
                    <span class="analysis-value">${analysis.marketStructure.amdxPhase}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Trend:</span>
                    <span class="analysis-value">${analysis.marketStructure.trend}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Strength:</span>
                    <span class="analysis-value">${analysis.marketStructure.strength}</span>
                </div>
            </div>

            <div class="analysis-card">
                <h4>🎯 Key Levels</h4>
                <div class="analysis-item">
                    <span class="analysis-label">Order Block:</span>
                    <span style="color: #eab308; font-family: monospace;">${analysis.keyLevels.orderBlock}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">FVG:</span>
                    <span style="color: #a855f7; font-family: monospace;">${analysis.keyLevels.fvg}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Liquidity:</span>
                    <span style="color: #f97316; font-family: monospace;">${analysis.keyLevels.liquidity}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Support:</span>
                    <span style="color: #22c55e; font-family: monospace;">${analysis.keyLevels.support}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Resistance:</span>
                    <span style="color: #ef4444; font-family: monospace;">${analysis.keyLevels.resistance}</span>
                </div>
            </div>

            <div class="analysis-card">
                <h4>📊 Indicators</h4>
                <div class="analysis-item">
                    <span class="analysis-label">RSI:</span>
                    <span style="color: ${analysis.indicators.rsi > 70 ? '#ef4444' : analysis.indicators.rsi < 30 ? '#22c55e' : 'white'}; font-family: monospace;">
                        ${analysis.indicators.rsi}
                    </span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">MACD:</span>
                    <span class="analysis-value">${analysis.indicators.macd}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">EMA:</span>
                    <span class="analysis-value">${analysis.indicators.ema}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Volume:</span>
                    <span class="analysis-value">${analysis.indicators.volume}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Momentum:</span>
                    <span class="analysis-value">${analysis.indicators.momentum}</span>
                </div>
            </div>
        </div>

        <div class="analysis-card">
            <h4>🌍 Session Analysis</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; font-size: 0.875rem;">
                <div>
                    <h5 style="color: #eab308; font-weight: 500; margin-bottom: 0.5rem;">🌅 Asia Session</h5>
                    <p style="color: #d1d5db;">${analysis.sessionAnalysis.asia}</p>
                </div>
                <div>
                    <h5 style="color: #3b82f6; font-weight: 500; margin-bottom: 0.5rem;">🌍 London Session</h5>
                    <p style="color: #d1d5db;">${analysis.sessionAnalysis.london}</p>
                </div>
                <div>
                    <h5 style="color: #22c55e; font-weight: 500; margin-bottom: 0.5rem;">🗽 New York Session</h5>
                    <p style="color: #d1d5db;">${analysis.sessionAnalysis.newYork}</p>
                </div>
            </div>
        </div>
    `;
}

function renderFundamentalAnalysis() {
    const container = document.getElementById('fundamentalAnalysis');
    
    container.innerHTML = `
        <div class="analysis-grid">
            <div class="analysis-card">
                <h4>📈 Market Sentiment</h4>
                <div class="analysis-item">
                    <span class="analysis-label">Overall:</span>
                    <span class="badge badge-green" style="background-color: #22c55e; color: white; font-size: 0.75rem; padding: 0.25rem 0.5rem;">
                        ${mockFundamentalAnalysis.marketSentiment.overall}
                    </span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">VIX:</span>
                    <span style="font-family: monospace; color: white;">${mockFundamentalAnalysis.marketSentiment.vix}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">DXY:</span>
                    <span class="analysis-value">${mockFundamentalAnalysis.marketSentiment.dxy}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Yields:</span>
                    <span class="analysis-value">${mockFundamentalAnalysis.marketSentiment.yields}</span>
                </div>
                <div class="analysis-item">
                    <span class="analysis-label">Crypto:</span>
                    <span style="color: #22c55e;">${mockFundamentalAnalysis.marketSentiment.crypto}</span>
                </div>
            </div>

            <div class="analysis-card">
                <h4>💪 Currency Strength</h4>
                ${Object.entries(mockFundamentalAnalysis.currencyStrength).map(([currency, data]) => `
                    <div class="analysis-item">
                        <span class="analysis-label" style="font-weight: 500;">${currency}:</span>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <span class="badge" style="background-color: ${
                                data.strength === 'Strong' || data.strength === 'Very Strong' ? '#22c55e' :
                                data.strength === 'Moderate' ? '#eab308' : '#ef4444'
                            }; color: white; font-size: 0.75rem; padding: 0.25rem 0.5rem;">
                                ${data.strength}
                            </span>
                            <span style="font-family: monospace; color: white;">${data.score}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="analysis-card">
            <h4>🔑 Key Market Factors</h4>
            <div style="font-size: 0.875rem; color: #d1d5db;">
                ${mockFundamentalAnalysis.keyFactors.map(factor => `
                    <div style="display: flex; align-items: flex-start; gap: 0.5rem; margin-bottom: 0.5rem;">
                        <span style="color: #3b82f6; margin-top: 0.25rem;">•</span>
                        <span>${factor}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function renderCalendar() {
    const container = document.getElementById('calendarEvents');
    
    container.innerHTML = mockNews.map(news => {
        const impactColors = {
            high: '#ef4444',
            medium: '#eab308',
            low: '#22c55e'
        };
        
        return `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 1rem; background-color: #111827; border-radius: 0.5rem; border: 1px solid #374151; margin-bottom: 0.75rem; transition: all 0.2s;" onmouseover="this.style.backgroundColor='#1f2937'" onmouseout="this.style.backgroundColor='#111827'">
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <div style="display: flex; flex-direction: column; align-items: center;">
                        <span style="font-size: 0.875rem; color: #9ca3af; font-weight: 500;">${news.time}</span>
                        <div style="width: 12px; height: 12px; border-radius: 50%; background-color: ${impactColors[news.impact]}; margin-top: 0.25rem;"></div>
                    </div>
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.25rem;">
                            <span style="font-size: 0.75rem; border: 1px solid #4b5563; padding: 0.25rem 0.5rem; border-radius: 0.375rem; font-weight: 500;">
                                ${news.currency}
                            </span>
                            <span style="color: white; font-weight: 500;">${news.event}</span>
                        </div>
                        <div style="font-size: 0.875rem; color: #9ca3af; margin-bottom: 0.5rem;">
                            ${news.description}
                        </div>
                        <div style="display: flex; gap: 1rem; font-size: 0.75rem;">
                            <span style="color: #9ca3af;">
                                Forecast: <span style="color: white; font-family: monospace;">${news.forecast}</span>
                            </span>
                            <span style="color: #9ca3af;">
                                Previous: <span style="color: white; font-family: monospace;">${news.previous}</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

function updateTime() {
    const now = new Date();
    document.getElementById('currentTime').textContent = now.toLocaleTimeString();
    document.getElementById('technicalTime').textContent = now.toLocaleTimeString();
    document.getElementById('calendarDate').textContent = now.toLocaleDateString();
}

